jQuery(document).ready(function(){			
			jQuery(".gallery a[rel^='prettyPhoto']").prettyPhoto({counter_separator_label:' of ',theme:'light_rounded',overlay_gallery:true});
		});